package Project3;

import java.io.*;
import java.net.*;

public class Client {
	private DatagramSocket socket = null;
	private FileEvent event = null;
	private String sourceFilePath = "C:/Users/Preto/Pictures/2.txt";
	private String destinationPath = "C:/Users/Preto/Downloads/";
	private String hostName = "localHost";

	public Client() {

	}

	public void createConnection() {
		// Create connection via IPAddress
		try {
			socket = new DatagramSocket();
			InetAddress IPAddress = InetAddress.getByName(hostName);
			// Send Data
			byte[] inData = new byte[1024];
			event = getFileEvent();
			// Output stream of the data
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ObjectOutputStream outStream = new ObjectOutputStream(out);
			outStream.writeObject(event);
			// Output packets
			byte[] data = out.toByteArray();
			DatagramPacket sendPacket = new DatagramPacket(data, data.length, IPAddress, 9876);
			socket.send(sendPacket);
			System.out.println("File sent from client");
			DatagramPacket incomingPacket = new DatagramPacket(inData, inData.length);
			socket.receive(incomingPacket);
			String response = new String(incomingPacket.getData());
			System.out.println("Response from server:" + response);
			Thread.sleep(2000);
			// Exit
			System.exit(0);

		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Handling the file
	public FileEvent getFileEvent() {
		FileEvent fileEvent = new FileEvent();
		String fileName = sourceFilePath.substring(sourceFilePath.lastIndexOf("/") + 1, sourceFilePath.length());
		String path = sourceFilePath.substring(0, sourceFilePath.lastIndexOf("/") + 1);
		// Change path
		fileEvent.setDestinationDirectory(destinationPath);
		fileEvent.setFilename(fileName);
		fileEvent.setSourceDirectory(sourceFilePath);
		File file = new File(sourceFilePath);
		// Check if pointed to an actual file 
		if (file.isFile()) {
			try {
				DataInputStream inStream = new DataInputStream(new FileInputStream(file));
				long length = (int) file.length();
				byte[] fileBytes = new byte[(int) length];
				int read = 0;
				int numRead = 0;
				while (read < fileBytes.length
						&& (numRead = inStream.read(fileBytes, read, fileBytes.length - read)) >= 0) {
					read = read + numRead;
				}
				fileEvent.setFileSize(length);
				fileEvent.setFileData(fileBytes);
				fileEvent.setStatus("Success");
			} catch (Exception e) {
				e.printStackTrace();
				fileEvent.setStatus("Error");
			}
		} else {
			System.out.println("path specified is not pointing to a file");
			fileEvent.setStatus("Error");
		}
		return fileEvent;
	}

	public static void main(String[] args) {
		Client client = new Client();
		client.createConnection();
	}
}