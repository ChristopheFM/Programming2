package Project3;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class Server {
	private DatagramSocket socket = null;
	private FileEvent fileEvent = null;

	public Server() {

	}

	public void createAndListenSocket() {
		try {
			// Create connection 
			socket = new DatagramSocket(9876);
			byte[] incomingData = new byte[1024 * 1000 * 50];
			while (true) {
				DatagramPacket inPacket = new DatagramPacket(incomingData, incomingData.length);
				socket.receive(inPacket);
				// Retrieve Data
				byte[] data = inPacket.getData();
				// Input stream of the data
				ByteArrayInputStream in = new ByteArrayInputStream(data);
				ObjectInputStream inStream = new ObjectInputStream(in);
				fileEvent = (FileEvent) inStream.readObject();
				if (fileEvent.getStatus().equalsIgnoreCase("Error")) {
					System.out.println("Some issue happened while packing the data @ client side");
					System.exit(0);
				}
				// Writing the file to hard disk
				createAndWriteFile(); 
				InetAddress IPAddress = inPacket.getAddress();
				int port = inPacket.getPort();
				String reply = "Thank you for the message";
				byte[] replyBytea = reply.getBytes();
				DatagramPacket replyPacket = new DatagramPacket(replyBytea, replyBytea.length, IPAddress, port);
				socket.send(replyPacket);
				Thread.sleep(3000);
				// Exit
				System.exit(0);

			}

		} catch (SocketException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Create the file
	public void createAndWriteFile() {
		String outputFile = fileEvent.getDestinationDirectory() + fileEvent.getFilename();
		if (!new File(fileEvent.getDestinationDirectory()).exists()) {
			new File(fileEvent.getDestinationDirectory()).mkdirs();
		}
		File dstFile = new File(outputFile);
		FileOutputStream fileOutputStream = null;
		// Check if the file is successfully saved
		try {
			fileOutputStream = new FileOutputStream(dstFile);
			fileOutputStream.write(fileEvent.getFileData());
			fileOutputStream.flush();
			fileOutputStream.close();
			System.out.println("Output file : " + outputFile + " is successfully saved ");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		Server server = new Server();
		server.createAndListenSocket();
	}
}