package Project2;

import java.io.*;
import java.net.*;

public class Server {
	public static void main(String[] args) throws IOException {
		final int port = 444;
		System.out.println("Server waiting for connection on port " + port);
		//create Server Socket
		ServerSocket serverSocket = new ServerSocket(port);
		Socket clientSocket = serverSocket.accept();
		System.out.println(
				"Recieved connection from " + clientSocket.getInetAddress() + " on port " + clientSocket.getPort());
		
		// create two threads to send and receive from client
		ReceiveFromClient receive = new ReceiveFromClient(clientSocket);
		Thread thread = new Thread(receive);
		thread.start();
		
		SendToClient send = new SendToClient(clientSocket);
		Thread thread2 = new Thread(send);
		thread2.start();
	}
}

// Receive-From-A-Client-Thread
class ReceiveFromClient implements Runnable {
	Socket clientSocket = null;
	BufferedReader bReader = null;

	// Initialize constructor
	public ReceiveFromClient(Socket clientSocket) {
		this.clientSocket = clientSocket;
	}

	// Run() for the Thread class
	public void run() {
		try {
			bReader = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));

			// Assign message from client to messageString
			String messageString;
			while (true) {
				while ((messageString = bReader.readLine()) != null) {
					if (messageString.equals("EXIT")) {
						// break to close socket if EXIT
						break;
					}
					// print the message from client
					System.out.println("From Client: " + messageString);
					System.out.println("Please enter something to send back to client..");
				}
				// Close
				this.clientSocket.close();
				System.exit(0);
			}

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
}

class SendToClient implements Runnable {
	PrintWriter printWriter;
	Socket clientSock = null;

	public SendToClient(Socket clientSock) {
		this.clientSock = clientSock;
	}

	public void run() {
		// Get Output-stream
		try {
			printWriter = new PrintWriter(new OutputStreamWriter(this.clientSock.getOutputStream()));

			// Get the user's input
			while (true) {
				String msg = null;
				BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

				// Get message to send to the client
				msg = input.readLine();

				// Send message to client
				printWriter.println(msg);
				
				// Flush the PrintWriter
				printWriter.flush();
				System.out.println("Please enter something to send back to client..");
			} 
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
}