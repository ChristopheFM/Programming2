package Project2;

import java.io.*;
import java.net.*;

public class Client {
	public static void main(String[] args) {
		try {
			// create socket with port
			Socket socket = new Socket("localhost", 444);
			
			//creating a Sending Thread
			SendThread sendThread = new SendThread(socket);
			Thread thread = new Thread(sendThread);
			thread.start();
			
			//creating a Receiving Thread
			ReceiveThread receiveThread = new ReceiveThread(socket);
			Thread thread2 = new Thread(receiveThread);
			thread2.start();
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

class ReceiveThread implements Runnable {
	Socket socket = null;
	BufferedReader receive = null;

	// Initialize socket
	public ReceiveThread(Socket socket) {
		this.socket = socket;
	}

	// Run() for the Start() ReceiveThread
	public void run() {
		try {
			// Output from the console text
			receive = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			String msg = null;
			while ((msg = receive.readLine()) != null) {
				System.out.println("From Server: " + msg);
				System.out.println("Please enter something to send to server..");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

class SendThread implements Runnable {
	Socket socket = null;
	PrintWriter print = null;
	BufferedReader bReader = null;

	// Initialize socket
	public SendThread(Socket socket) {
		this.socket = socket;
	}

	// Run() for the Start() ReceiveThread
	public void run() {
		try {
			if (socket.isConnected()) {
				// Print connection if connected
				System.out.println("Client connected to " + socket.getInetAddress() + " on port " + socket.getPort());
				this.print = new PrintWriter(socket.getOutputStream(), true);
				// Read message until 'EXIT' is entered
				while (true) {
					System.out.println("Type your message to send to server..type 'EXIT' to exit");
					bReader = new BufferedReader(new InputStreamReader(System.in));
					// Message to read from the Buffer
					String msg = null;
					msg = bReader.readLine();
					this.print.println(msg);
					this.print.flush();

					// Quit the application
					if (msg.equals("EXIT"))
						break;
				}
				socket.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}