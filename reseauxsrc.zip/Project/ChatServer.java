package Project;

import java.net.*;
import java.io.*;

public class ChatServer {

	// Creating ChatServer
	public ChatServer(int port) throws IOException {
		// Creating new socket with a port
		ServerSocket chatServer = new ServerSocket(port);
		// Start server
		while (true) {
			Socket client = chatServer.accept();
			System.out.println("Accepted from " + client.getInetAddress());
			ChatHandler cHandler = new ChatHandler(client);
			cHandler.start();
		}
	}

	// Launch an create Server
	public static void main(String args[]) throws IOException {
		if (args.length != 1)
			throw new RuntimeException("Syntax: ChatServer <port>");
		new ChatServer(Integer.parseInt(args[0]));
	}
}