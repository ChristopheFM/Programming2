package Project;

import java.net.*;
import java.io.*;
import java.util.*;

public class ChatHandler extends Thread {

	protected Socket socket;
	protected DataInputStream in;
	protected DataOutputStream out;

	// Input an Output handler
	public ChatHandler(Socket socket) throws IOException {
		this.socket = socket;
		in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
		out = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
	}

	protected static Vector<ChatHandler> handlers = new Vector<ChatHandler>();

	// Run Chathandler as a Thread
	public void run() {
		try {
			//reading message
			handlers.addElement(this);
			while (true) {
				String msg = in.readUTF();
				broadcast(msg);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			// Properly close handler
			handlers.removeElement(this);
			try {
				socket.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	// Broadcast: While there is an element the methods keeps reading
	protected static void broadcast(String msg) {
		synchronized (handlers) {
			Enumeration<ChatHandler> cHandler = handlers.elements();
			while (cHandler.hasMoreElements()) {
				ChatHandler c = (ChatHandler) cHandler.nextElement();
				try {
					//Response
					synchronized (c.out) {
						c.out.writeUTF(msg);
					}
					//Flush the output-stream
					c.out.flush();
				} catch (IOException ex) {
					c.stop();
				}
			}
		}
	}
}
