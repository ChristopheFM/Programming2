package Project;

import java.net.*;
import java.io.*;
import java.awt.*;

public class Client extends Frame implements Runnable {
	
	protected DataInputStream in;
	protected DataOutputStream out;
	protected TextArea output;
	protected TextField input;
	protected Thread listener;
	
	// Initialize Client with a view
	public Client(String title, InputStream in, OutputStream out) {
		super(title);
		
		// Input and Output Streams
		this.in = new DataInputStream(new BufferedInputStream(in));
		this.out = new DataOutputStream(new BufferedOutputStream(out));
		
		// Creating Graphical Interface 
		setLayout(new BorderLayout());
		add("Center", output = new TextArea());
		output.setEditable(false);
		add("South", input = new TextField());
		pack();
		show();
		
		//Focusing on the Client's window while launching client
		input.requestFocus();
		
		//Creating Client-Thread
		listener = new Thread(this);
		listener.start();
	}

	// Run Client-Thread
	public void run() {
		try {
			// Reading Input and send as output
			while (true) {
				String stringLine = in.readUTF();
				output.appendText(stringLine + "\n");
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			// Close Client
			listener = null;
			input.hide();
			validate();
			try {
				out.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	// Handle output for the Client-Interface an close it properly
	public boolean handleEvent(Event evt) {
		if ((evt.target == input) && (evt.id == Event.ACTION_EVENT)) {
			try {
				out.writeUTF((String) evt.arg);
				out.flush();
			} catch (IOException ex) {
				ex.printStackTrace();
				listener.stop();
			}
			input.setText("");
			return true;
		// Close application if windows is closed
		} else if ((evt.target == this) && (evt.id == Event.WINDOW_DESTROY)) {
			if (listener != null)
				listener.stop();
			hide();
			return true;
		}
		return super.handleEvent(evt);
	}

	// Run Client
	public static void main(String args[]) throws IOException {
		if (args.length != 2)
			throw new RuntimeException("Syntax: ChatClient <host> <port>");
		Socket s = new Socket(args[0], Integer.parseInt(args[1]));
		new Client("Chat " + args[0] + ":" + args[1], s.getInputStream(),
				s.getOutputStream());
	}
}